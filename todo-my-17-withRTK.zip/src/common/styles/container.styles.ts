import {SxProps} from "@mui/material";

export const filterBtnsContainerSX: SxProps =
    {
        display: 'flex',
        gap: '10px',
        justifyContent: 'space-around',
    }

