import { createAction } from "@reduxjs/toolkit"

export const clearDataAC = createAction("common/clearData")
