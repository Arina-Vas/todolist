export const Faq = () => {
  return <h1>Здесь будут вопросы...</h1>
}
