import { changeAppErrorAC, changeStatusAC } from "@/app/app-slice.ts"
import { Dispatch } from "@reduxjs/toolkit"
import { BaseResponse } from "@/common/types/types.ts"
import { z } from "zod"

export const handleServerAppError = <T extends z.ZodType<object>>(dispatch: Dispatch, data: BaseResponse<T>): void => {
  if (data.messages.length) {
    dispatch(changeAppErrorAC({ error: data.messages[0] }))
  } else {
    dispatch(changeAppErrorAC({ error: "Some error occurred" }))
  }
  dispatch(changeStatusAC({ status: "failed" }))
}

