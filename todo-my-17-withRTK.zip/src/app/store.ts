import { configureStore } from "@reduxjs/toolkit"
import { taskReducer, tasksSlice } from "@/features/todolists/model/tasks-slice.ts"
import { todolistReducer, todolistSlice } from "@/features/todolists/model/todolists-slice.ts"
import { appReducer, appSlice } from "@/app/app-slice.ts"
import { authReducer, authSlice } from "@/features/auth/model/auth-slice.ts"
import { todolistApi } from "@/features/todolists/api/todolistsApi.ts"
import { setupListeners } from "@reduxjs/toolkit/query"


// объединение reducer'ов с помощью combineReducers
export const store = configureStore({
    reducer:
      {
        [tasksSlice.name]: taskReducer,
        [todolistSlice.name]: todolistReducer,
        [appSlice.name]: appReducer,
        [authSlice.name]: authReducer,
        [todolistApi.reducerPath]: todolistApi.reducer
      },
  middleware: getDefaultMiddleware => getDefaultMiddleware().concat(todolistApi.middleware)
  }
)

setupListeners(store.dispatch)

// автоматическое определение типа всего объекта состояния
export type RootState = ReturnType<typeof store.getState>
// автоматическое определение типа метода dispatch
export type AppDispatch = typeof store.dispatch
