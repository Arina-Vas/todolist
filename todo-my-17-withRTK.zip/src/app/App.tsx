import "./App.module.css"
import { CircularProgress, CssBaseline, ThemeProvider } from "@mui/material"
import styles from "./App.module.css"
import { useEffect, useState } from "react"
import { useAppDispatch, useAppSelector } from "@/common/hooks"
import { selectThemeMode } from "@/app/app-slice.ts"
import { getTheme } from "@/common/theme"
import { initializeAppTC } from "@/features/auth/model/auth-slice.ts"
import { Header } from "@/common/Components/Header/Header.tsx"
import { Routing } from "@/common/routing"
import { ErrorSnackbar } from "@/common/Components"

export const App = () => {
  const [isInitialized, setIsInitialized] = useState(false)
  const themeMode = useAppSelector(selectThemeMode)
  const theme = getTheme(themeMode)
  const dispatch = useAppDispatch()
  useEffect(() => {
    dispatch(initializeAppTC()).finally(() => setIsInitialized(true))
  }, [])

  if (!isInitialized) {
    return (
      <ThemeProvider theme={theme}>
        <div className={styles.circularProgressContainer}>
          <CircularProgress size={150} thickness={3} color={"primary"} />
        </div>
      </ThemeProvider>
    )
  }

  return (
    <ThemeProvider theme={theme}>
      <div className={styles.app}>
        <CssBaseline />
        <Header />
        <Routing />
        <ErrorSnackbar />
      </div>
    </ThemeProvider>
  )
}

export default App
