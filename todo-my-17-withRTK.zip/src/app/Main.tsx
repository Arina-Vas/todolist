import Grid from "@mui/material/Grid2"
import { useAppDispatch } from "@/common/hooks"
import { addTodolistTC } from "@/features/todolists/model/todolists-slice.ts"
import { Container } from "@mui/material"
import { AddItemForm } from "@/common/Components/AddItemForm/AddItemForm.tsx"
import { Todolists } from "@/features/todolists/ui/Todolists/Todolists.tsx"

export const Main = () => {
  const dispatch = useAppDispatch()
  const addTodoList = (title: string) => {
    dispatch(addTodolistTC({ title }))
  }

  return (
    <Container fixed>
      <Grid sx={{ ml: "30px" }}>
        <AddItemForm addItem={addTodoList} />
      </Grid>
      <Grid container spacing={2}>
        <Todolists />
      </Grid>
    </Container>
  )
}
