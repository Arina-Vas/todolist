import { instance } from "@/common/instance/instance.ts"
import { AuthResponse, LoginArgs, MeResponse } from "@/features/auth/api/authApi.types.ts"
import { DefaultResponse } from "@/common/types/types.ts"

export const AuthApi = {
  login(payload: LoginArgs) {
    return instance.post<AuthResponse>("auth/login", payload)
  },
  logout() {
    return instance.delete<DefaultResponse>("auth/login")
  },
  me() {
    return instance.get<MeResponse>("auth/me")
  },
}
