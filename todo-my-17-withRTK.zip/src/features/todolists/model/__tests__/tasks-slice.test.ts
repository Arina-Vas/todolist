import { beforeEach, expect, test } from 'vitest'
import {
    createTaskTC,
    deleteTaskTC,
    taskReducer,
    TasksType, updateTask,
} from "../tasks-slice.ts"
import { addTodolistTC, deleteTodolistTC } from "../todolists-slice.ts"
import { TaskPriority, TaskStatus } from "@/common/enums"
import { nanoid } from "@reduxjs/toolkit"

const taskDefaultValues = {
    description: '',
    deadline: '',
    addedDate: '',
    startDate: '',
    priority: TaskPriority.Low,
    order: 0,
}

let startState: TasksType = {}

beforeEach(() => {
    startState = {
        todolistId1: [
            {
                id: '1',
                title: 'CSS',
                status: TaskStatus.New,
                todoListId: 'todolistId1',
                ...taskDefaultValues,
            },
            {
                id: '2',
                title: 'JS',
                status: TaskStatus.Completed,
                todoListId: 'todolistId1',
                ...taskDefaultValues,
            },
            {
                id: '3',
                title: 'React',
                status: TaskStatus.New,
                todoListId: 'todolistId1',
                ...taskDefaultValues,
            },
        ],
        todolistId2: [
            {
                id: '1',
                title: 'bread',
                status: TaskStatus.New,
                todoListId: 'todolistId2',
                ...taskDefaultValues,
            },
            {
                id: '2',
                title: 'milk',
                status: TaskStatus.Completed,
                todoListId: 'todolistId2',
                ...taskDefaultValues,
            },
            {
                id: '3',
                title: 'tea',
                status: TaskStatus.New,
                todoListId: 'todolistId2',
                ...taskDefaultValues,
            },
        ],
    }
})

test('property with todolistId should be deleted', () => {
    const endState = taskReducer(startState, deleteTodolistTC.fulfilled({id:'todolistId2'},'requestId', { id: "todolistId2" }))

    const keys = Object.keys(endState)
    expect(keys.length).toBe(1)
    expect(endState['todolistId2']).not.toBeDefined()
    // or
    expect(endState['todolistId2']).toBeUndefined()
})

test('array should be created for new todolist', () => {
    const title = "New todolist"
    const todolist = { id: "todolistId3", title, addedDate: "", order: 0 }
    const endState = taskReducer(startState, addTodolistTC.fulfilled(todolist, "requestId", { title }))

    const keys = Object.keys(endState)
    const newKey = keys.find(k => k !== 'todolistId1' && k !== 'todolistId2')
    if (!newKey) {
        throw Error('New key should be added')
    }

    expect(keys.length).toBe(3)
    expect(endState[newKey]).toEqual([])
})

test('correct task should be deleted', () => {
    const endState = taskReducer(startState, deleteTaskTC.fulfilled({todolistId:'todolistId1',taskId: '2'},"requestId",{
        todolistId: 'todolistId2',
        taskId: '2'
    }))

    expect(endState['todolistId1'].length).toBe(2)
    expect(endState['todolistId2'].length).toBe(3)
    expect(endState['todolistId1'][1].id).toBe('3')
    expect(endState['todolistId2'][1].id).toBe('2')
})

test("correct task should be created at correct array", () => {
    const task = {
        id: nanoid(),
        title: "juice",
        status: TaskStatus.New,
        description: "",
        deadline: "",
        addedDate: "",
        startDate: "",
        priority: TaskPriority.Low,
        order: 0,
        todoListId: "todolistId2",
    }
    const endState = taskReducer(
      startState,
      createTaskTC.fulfilled({ task }, "requestId", { todolistId: "todolistId2", title: "juice" }),
    )

    expect(endState['todolistId1'].length).toBe(3)
    expect(endState['todolistId2'].length).toBe(4)
    expect(endState['todolistId2'][0].title).toBe("juice")
    expect(endState['todolistId2'][0].status).toBe(TaskStatus.New)
})

test('correct task should change its title', () => {
    const taskForUpdate = {
        id: '1',
        title: 'New title',
        status: TaskStatus.New,
        todoListId: 'todolistId2',
        ...taskDefaultValues,
    }
    const endState = taskReducer(
      startState,
      updateTask.fulfilled({task: taskForUpdate }, "requestId", taskForUpdate ),
    )


    expect(endState['todolistId2'][0].title).toBe('New title')
    expect(endState['todolistId1'][0].title).toBe('CSS')
})

test('correct task should change its status', () => {
    const taskForUpdate = {
        id: '1',
        title: 'bread',
        status: TaskStatus.Completed,
        todoListId: 'todolistId2',
        ...taskDefaultValues,
    }
    const endState = taskReducer(
      startState,
      updateTask.fulfilled({task: taskForUpdate }, "requestId", taskForUpdate ),
    )


    expect(endState['todolistId2'][0].title).toBe('bread')
    expect(endState['todolistId2'][0].status).toBe(TaskStatus.Completed)
    expect(endState['todolistId1'][0].status).toBe(TaskStatus.New)
})