import { createAppSlice, handleServerAppError, handleServerNetworkError } from "@/common/utils"
import { TodolistResponseSchema, Todolists, TodolistSchema } from "@/features/todolists/api/todolistsApi.types.ts"
import { changeStatusAC, RequestStatus } from "@/app/app-slice.ts"
import { _todolistsApi } from "@/features/todolists/api/todolistsApi.ts"
import { ResultCode } from "@/common/enums"
import { DefaultResponseSchema } from "@/common/types/types.ts"
import { clearDataAC } from "@/common/actions"

export type FilterType = "all" | "active" | "completed"
export type TodoListType = Todolists & {
  filter: FilterType
  entityStatus: RequestStatus
}

const initialState = [] as TodoListType[]

export const todolistSlice = createAppSlice({
  name: "todolists",
  initialState,
  reducers: (create) => ({
    fetchTodolistsTC: create.asyncThunk(
      async (_arg, { dispatch, rejectWithValue }) => {
        try {
          dispatch(changeStatusAC({ status: "loading" }))
          const res = await _todolistsApi.getTodolists()
          const todolists = TodolistSchema.array().parse(res.data)
          dispatch(changeStatusAC({ status: "succeeded" }))
          return { todolists }
        } catch (error) {
          handleServerNetworkError(dispatch, error)
          return rejectWithValue(null)
        }
      },
      {
        fulfilled: (_state, action) => {
          return action.payload.todolists.map((tl) => ({ ...tl, filter: "all", entityStatus: "idle" }))
        },
      },
    ),
    addTodolistTC: create.asyncThunk(
      async (args: { title: string }, { rejectWithValue, dispatch }) => {
        try {
          dispatch(changeStatusAC({ status: "loading" }))
          const res = await _todolistsApi.createTodolist(args.title)
          const todolist = TodolistResponseSchema.parse(res.data).data.item
          if (res.data.resultCode === ResultCode.Success) {
            dispatch(changeStatusAC({ status: "succeeded" }))
            return todolist
          } else {
            handleServerAppError(dispatch, res.data)
            return rejectWithValue(null)
          }
        } catch (error: unknown) {
          handleServerNetworkError(dispatch, error)
          return rejectWithValue(null)
        }
      },
      {
        fulfilled: (state, action) => {
          state.unshift({ ...action.payload, filter: "all", addedDate: "", order: 1, entityStatus: "idle" })
        },
      },
    ),
    deleteTodolistTC: create.asyncThunk(
      async (arg: { id: string }, { rejectWithValue, dispatch }) => {
        try {
          dispatch(changeStatusAC({ status: "loading" }))
          dispatch(changeTodolistEntityStatusAC({ todolistId: arg.id, entityStatus: "loading" }))
          const res = await _todolistsApi.deleteTodolist(arg.id)
          DefaultResponseSchema.parse(res.data)
          if (res.data.resultCode === ResultCode.Success) {
            dispatch(changeStatusAC({ status: "succeeded" }))
            return arg
          } else {
            handleServerAppError(dispatch, res.data)
            return rejectWithValue(null)
          }
        } catch (error) {
          handleServerNetworkError(dispatch, error)
          return rejectWithValue(null)
        }
      },
      {
        fulfilled: (state, action) => {
          const i = state.findIndex((tl) => tl.id === action.payload.id)
          if (i !== -1) {
            state.splice(i, 1)
          }
        },
      },
    ),
    changeTodolistTitleTC: create.asyncThunk(
      async (args: { id: string; title: string }, { rejectWithValue, dispatch }) => {
        try {
          dispatch(changeStatusAC({ status: "loading" }))
          const res = await _todolistsApi.changeTodolistTitle({ ...args })
          DefaultResponseSchema.parse(res.data)
          if (res.data.resultCode === ResultCode.Success) {
            dispatch(changeStatusAC({ status: "succeeded" }))
            return args
          } else {
            handleServerAppError(dispatch, res.data)
            return rejectWithValue(null)
          }
        } catch (error) {
          handleServerNetworkError(dispatch, error)
          return rejectWithValue(null)
        }
      },
      {
        fulfilled: (state, action) => {
          const i = state.findIndex((tl) => tl.id === action.payload.id)
          if (i !== -1) {
            state[i].title = action.payload.title
          }
        },
      },
    ),
    changeTodolistFilterAC: create.reducer<{ todolistId: string; filter: FilterType }>((state, action) => {
      const todolist = state.find((tl) => tl.id === action.payload.todolistId)
      if (todolist) {
        todolist.filter = action.payload.filter
      }
    }),
    changeTodolistEntityStatusAC: create.reducer<{ todolistId: string; entityStatus: RequestStatus }>(
      (state, action) => {
        const todolist = state.find((tl) => tl.id === action.payload.todolistId)
        if (todolist) {
          todolist.entityStatus = action.payload.entityStatus
        }
      },
    ),
  }),
  selectors: {
    selectTodolists: (state): TodoListType[] => state,
  },
  extraReducers: (builder) => {
    builder.addCase(clearDataAC, () => {
      return initialState
    })
  },
})

export const {
  addTodolistTC,
  changeTodolistFilterAC,
  deleteTodolistTC,
  fetchTodolistsTC,
  changeTodolistTitleTC,
  changeTodolistEntityStatusAC,
} = todolistSlice.actions
export const todolistReducer = todolistSlice.reducer
export const { selectTodolists } = todolistSlice.selectors
