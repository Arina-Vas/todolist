import { addTodolistTC, deleteTodolistTC } from "./todolists-slice.ts"
import { DomainTask, GetTasksResponseSchema, TaskResponseSchema } from "@/features/todolists/api/tasksApi.types.ts"
import { createAppSlice, handleServerAppError, handleServerNetworkError } from "@/common/utils"
import { changeStatusAC } from "@/app/app-slice.ts"
import { tasksApi } from "@/features/todolists/api/tasksApi.ts"
import { ResultCode } from "@/common/enums"
import { DefaultResponseSchema } from "@/common/types/types.ts"
import { clearDataAC } from "@/common/actions"

export type TasksType = Record<string, DomainTask[]>
const initialState = {} as TasksType

export const tasksSlice = createAppSlice({
  name: "tasks",
  initialState,
  reducers: (create) => {
    return {
      fetchTaskTC: create.asyncThunk(
        async (todolistId: string, { rejectWithValue, dispatch }) => {
          try {
            dispatch(changeStatusAC({ status: "loading" }))
            const res = await tasksApi.getTasks(todolistId)
            GetTasksResponseSchema.parse(res.data)
            dispatch(changeStatusAC({ status: "succeeded" }))
            return { tasks: res.data.items, todolistId }
          } catch (err) {
            handleServerNetworkError(dispatch, err)
            return rejectWithValue(null)
          }
        },
        {
          fulfilled: (state, action) => {
            state[action.payload.todolistId] = action.payload.tasks
          },
        },
      ),
      createTaskTC: create.asyncThunk(
        async (payload: { todolistId: string; title: string }, { rejectWithValue, dispatch }) => {
          try {
            dispatch(changeStatusAC({ status: "loading" }))
            const res = await tasksApi.createTask(payload)
            TaskResponseSchema.parse(res.data)
            if (res.data.resultCode === ResultCode.Success) {
              dispatch(changeStatusAC({ status: "succeeded" }))
              return { task: res.data.data.item }
            } else {
              handleServerAppError(dispatch, res.data)
              return rejectWithValue(null)
            }
          } catch (err) {
            handleServerNetworkError(dispatch, err)
            return rejectWithValue(null)
          }
        },
        {
          fulfilled: (state, action) => {
            state[action.payload.task.todoListId].unshift(action.payload.task)
          },
        },
      ),
      deleteTaskTC: create.asyncThunk(
        async (payload: { todolistId: string; taskId: string }, { rejectWithValue, dispatch }) => {
          try {
            dispatch(changeStatusAC({ status: "loading" }))
            const res = await tasksApi.deleteTask(payload)
            DefaultResponseSchema.parse(res.data)
            if (res.data.resultCode === ResultCode.Success) {
              dispatch(changeStatusAC({ status: "succeeded" }))
              return payload
            } else {
              handleServerAppError(dispatch, res.data)
              return rejectWithValue(null)
            }
          } catch (err) {
            dispatch(changeStatusAC({ status: "failed" }))
            return rejectWithValue(null)
          }
        },
        {
          fulfilled: (state, action) => {
            const tasks = state[action.payload.todolistId]
            const index = tasks.findIndex((t) => t.id === action.payload.taskId)
            tasks.splice(index, 1)
          },
        },
      ),
      updateTask: create.asyncThunk(
        async (task: DomainTask, { rejectWithValue, dispatch }) => {
          try {
            dispatch(changeStatusAC({ status: "loading" }))
            const res = await tasksApi.updateTask({ taskId: task.id, todolistId: task.todoListId, model: task })
            TaskResponseSchema.parse(res.data)
            if (res.data.resultCode === ResultCode.Success) {
              dispatch(changeStatusAC({ status: "succeeded" }))
              return { task: res.data.data.item }
            } else {
              handleServerAppError(dispatch, res.data)
              return rejectWithValue(null)
            }
          } catch (error) {
            handleServerNetworkError(dispatch, error)
            return rejectWithValue(null)
          }
        },
        {
          fulfilled: (state, action) => {
            const task = action.payload.task
            if (task) {
              state[task.todoListId] = state[task.todoListId].map((t) =>
                t.id === action.payload.task.id ? action.payload.task : t,
              )
            }
          },
        },
      ),
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(addTodolistTC.fulfilled, (state, action) => {
        state[action.payload.id] = []
      })
      .addCase(deleteTodolistTC.fulfilled, (state, action) => {
        delete state[action.payload.id]
      })
      .addCase(clearDataAC, () => {
        return initialState
      })
  },
  selectors: {
    selectTasks: (state): TasksType => state,
  },
})

export const { createTaskTC, deleteTaskTC, updateTask, fetchTaskTC } = tasksSlice.actions
export const taskReducer = tasksSlice.reducer
export const { selectTasks } = tasksSlice.selectors
