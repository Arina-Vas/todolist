import { instance } from "@/common/instance/instance.ts"
import { TodolistResponse, Todolists } from "@/features/todolists/api/todolistsApi.types.ts"
import { DefaultResponse } from "@/common/types/types.ts"
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"
import { AUTH_TOKEN } from "@/common/constants"
import { TodoListType } from "@/features/todolists/model/todolists-slice.ts"

export const todolistApi = createApi({
  reducerPath: "todolistApi",
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_BASE_URL,
    prepareHeaders: (headers) => {
      headers.set("API-KEY", import.meta.env.VITE_API_KEY)
      headers.set("Authorization", `Bearer ${localStorage.getItem(AUTH_TOKEN)}`)
    }
  }),
  endpoints: (build) => ({
    getTodolists: build.query<TodoListType[], void>({
      query: () => "/todo-lists",
      transformResponse: (todolists: Todolists[]): TodoListType[] => todolists.map((tl) => ({
        ...tl,
        filter: "all",
        entityStatus: "idle"
      }))
    }),
    createTodolist:build.mutation<TodolistResponse, string>({
      query: (title) => ({
        url: `/todo-lists`,
        method: "POST",
        body: { title }
      })
    }),
    changeTodolistTitle: build.mutation<DefaultResponse, { id: string; title: string }>({
      query: ({ title, id }) => ({
        url: `/todo-lists/${id}`,
        method: "PUT",
        body: { title }
      })
    }),
    deleteTodolist: build.mutation<DefaultResponse, string>({
      query: ( id ) => ({
        url: `/todo-lists/${id}`,
        method: "DELETE"
      })
    }),
  })
})

export const {useGetTodolistsQuery, useCreateTodolistMutation,useDeleteTodolistMutation,useChangeTodolistTitleMutation} = todolistApi

export const _todolistsApi = {
  getTodolists() {
    return instance.get<Todolists[]>("/todo-lists")
  },
  changeTodolistTitle(payload: { id: string; title: string }) {
    const { id, title } = payload
    return instance.put<DefaultResponse>(`/todo-lists/${id}`, { title })
  },
  createTodolist(title: string) {
    return instance.post<TodolistResponse>("/todo-lists", { title })
  },
  deleteTodolist(id: string) {
    return instance.delete<DefaultResponse>(`/todo-lists/${id}`)
  }
}
