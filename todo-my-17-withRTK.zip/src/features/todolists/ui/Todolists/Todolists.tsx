import Grid from "@mui/material/Grid2"
import { Paper } from "@mui/material"
import { TodolistItem } from "@/features/todolists/ui/Todolists/TodolistItem/TodolistItem.tsx"
import { useGetTodolistsQuery } from "@/features/todolists/api/todolistsApi.ts"

export const Todolists = () => {
  const {data: todolists} = useGetTodolistsQuery()


  return (
    <>
      {todolists?.map((tl) => {
        return (
          <Grid key={tl.id} sx={{ p: "30px" }}>
            <Paper elevation={5} sx={{ p: "20px", borderRadius: "10px" }}>
              <TodolistItem todolist={tl} />
            </Paper>
          </Grid>
        )
      })}
    </>
  )
}
