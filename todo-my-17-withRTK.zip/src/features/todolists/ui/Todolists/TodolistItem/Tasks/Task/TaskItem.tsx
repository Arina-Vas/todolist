import { ChangeEvent } from "react"
import { EditableSpan } from "@/common/Components/EditableSpan/EditableSpan.tsx"
import { Checkbox, IconButton, ListItem } from "@mui/material"
import DeleteIcon from "@mui/icons-material/Delete"
import { deleteTaskTC, updateTask } from "@/features/todolists/model/tasks-slice.ts"
import { useAppDispatch } from "@/common/hooks/useAppDispatch.ts"
import { getListItemSx } from "@/features/todolists/ui/Todolists/TodolistItem/Tasks/Task/TaskItem.styles.ts"
import { DomainTask } from "@/features/todolists/api/tasksApi.types.ts"
import { TaskStatus } from "@/common/enums"
import { TodoListType } from "@/features/todolists/model/todolists-slice.ts"

type Props = {
  todolist: TodoListType
  task: DomainTask
}

export const TaskItem = ({ task, todolist }: Props) => {
  const dispatch = useAppDispatch()

  const removeTask = () => {
    dispatch(deleteTaskTC({ todolistId: todolist.id, taskId: task.id }))
  }

  // const updateTaskHandler = (el: ChangeEvent<HTMLInputElement> |  string) => {
  //   const domainModel: Partial<UpdateTaskModel> = {  }
  //   if (typeof el === "string") {
  //     domainModel.title = el
  //   }
  //   else {
  //     domainModel.status =  el.currentTarget.checked ? TaskStatus.Completed : TaskStatus.New
  //   }
  //   dispatch(
  //     updateTask({
  //       todolistId,
  //       taskId: task.id,
  //       domainModel
  //     }),
  //   )
  // }

  const updateTaskHandler = (el: ChangeEvent<HTMLInputElement> | string) => {
    if (typeof el === "string") {
      dispatch(
        updateTask({...task,title: el }),
      )
    } else {
      dispatch(updateTask({ ...task, status: el.currentTarget.checked ? TaskStatus.Completed : TaskStatus.New}))
    }
  }

  const newStatusValue = task.status === TaskStatus.Completed
  const className = newStatusValue ? "isDone" : ""
const disabled = todolist.entityStatus === 'loading'

  return (
    <ListItem className={`task ${className}`} sx={getListItemSx(newStatusValue)}>
      <div>
        <Checkbox id={task.id} onChange={updateTaskHandler} checked={newStatusValue} disabled={disabled} />
        <EditableSpan updateTitle={updateTaskHandler} oldTitle={task.title} disabled={disabled} />
        {/*<span> {new Date(task.addedDate).toLocaleDateString()}</span>*/}
      </div>
      <IconButton onClick={removeTask} size={"small"} disabled={disabled}>
        <DeleteIcon />
      </IconButton>
    </ListItem>
  )
}
