import { fetchTaskTC, selectTasks } from "@/features/todolists/model/tasks-slice.ts"
import List from "@mui/material/List"
import { TaskItem } from "@/features/todolists/ui/Todolists/TodolistItem/Tasks/Task/TaskItem.tsx"
import { useAppSelector } from "@/common/hooks/useAppSelector.ts"

import { TodoListType } from "@/features/todolists/model/todolists-slice.ts"
import { useAppDispatch } from "@/common/hooks/useAppDispatch.ts"
import { useEffect } from "react"
import { DomainTask } from "@/features/todolists/api/tasksApi.types.ts"
import { TaskStatus } from "@/common/enums"

type Props = {
  todolist: TodoListType
}
export const Tasks = ({ todolist }: Props) => {
  const { id, filter } = todolist
  const tasks = useAppSelector(selectTasks)[id]
  const dispatch = useAppDispatch()

  useEffect(() => {
    dispatch(fetchTaskTC(id))
  }, [])

  const filterFoo = (): DomainTask[] => {
    switch (filter) {
      case "completed":
        return tasks.filter((task: DomainTask) => task.status === TaskStatus.Completed)
      case "active":
        return tasks.filter((task: DomainTask) => task.status === TaskStatus.New)
      default:
        return tasks
    }
  }
  const mappedTask = filterFoo()?.map((task: DomainTask) => {
    return <TaskItem key={task.id} task={task} todolist={todolist} />
  })
  return <>{tasks?.length === 0 ? <p>Тасок нет</p> : <List>{mappedTask}</List>}</>
}
