import {EditableSpan} from "@/common/Components/EditableSpan/EditableSpan.tsx";
import {IconButton} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  changeTodolistTitleTC,
deleteTodolistTC,
  TodoListType
} from "@/features/todolists/model/todolists-slice.ts"
import {useAppDispatch} from "@/common/hooks/useAppDispatch.ts";
import styles from './TodolistTitle.module.css'

type Props = {
    todolist: TodoListType
};
export const TodolistTitle = ({todolist}: Props) => {
    const {id,title, entityStatus} = todolist
    const dispatch = useAppDispatch();

    const deleteTodoList = () => {
        dispatch(deleteTodolistTC({id}))
    }

    const updateTodoListTitle = (title: string ) => {
        dispatch(changeTodolistTitleTC({id, title}))
    }

    const disabled = entityStatus === 'loading'

    return (
        <div className={styles.container}>
            <h3>
                <EditableSpan updateTitle={updateTodoListTitle} oldTitle={title} disabled={disabled}/>
            </h3>
            <IconButton onClick={deleteTodoList} size={'small'} disabled={disabled}>
                <DeleteIcon/>
            </IconButton>
        </div>

    );
};