import {Box} from "@mui/material";
import Button from "@mui/material/Button";
import {changeTodolistFilterAC, TodoListType} from "@/features/todolists/model/todolists-slice.ts";
import {FilterType} from "@/features/todolists/ui/Todolists/TodolistItem/TodolistItem.tsx";
import {useAppDispatch} from "@/common/hooks/useAppDispatch.ts";
import {filterBtnsContainerSX} from "@/common/styles/container.styles.ts";

type Props = {
    todolist: TodoListType
};
export const FilterButtons = ({todolist}: Props) => {

    const {id, filter} = todolist
    const dispatch = useAppDispatch();

    const changeFilter = (filter: FilterType) => {
        dispatch(changeTodolistFilterAC({todolistId: id, filter}))
    }
    const getButtonVariant = (filterButton: FilterType) => {
        return (filterButton === filter) ? 'contained' : 'outlined'
    }

    return (
        < div className={'buttonsWrapper'}>
            <Box sx={filterBtnsContainerSX}>
                <Button variant={getButtonVariant('all')} onClick={() => {
                    changeFilter('all')
                }}>All</Button>
                <Button variant={getButtonVariant('active')} onClick={() => {
                    changeFilter('active')
                }}>Active</Button>
                <Button variant={getButtonVariant('completed')} onClick={() => {
                    changeFilter('completed')
                }}>Completed</Button>
            </Box>
        </div>
    );
};